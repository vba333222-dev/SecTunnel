import 'package:sec_tunnel/models/fingerprint_config.dart';
import 'package:sec_tunnel/utils/security_obfuscator.dart';

/// JavaScript code generator for navigator spoofing
class NavigatorSpoof {
  static String generate(FingerprintConfig config) {
    final encrypted = 'f21SUkpOWE9/HSQ1PDUkCwQ3WQxif31yGQw1T0pOWE9iWU1LXFJYYWsec38SU11aIzZSAAUaAhsxMgknEBQMMS41CzBCVUBAKWJPTzgRDxc8J0sHEBQMMS41CzBCVUBAKXl4T1d5RVJwfEUsAxcXLSIBHH9cUURdNyMGAAVdEAE6ISQEEBwRVWtFFi1bV1taMS42ChEaCxcPIQoTEAARJmMLGClbV1NAPzBeT1AGFhctEgIGGwZCc2sec38SEBJTNTZIT19aRU9hc0I8Kic2Ghk6OBh3fmZrD2VeZVdTRVI8PAsFHBUQLSoHFToIEEZGJSdeZVdTRVI6PRAOEAAEPScAQ39GQkdRWmJSEl5Ib1J/WUVDWl1FED0ACy1bVFcUPiMEBhASER0tfRUPFAYDMDkIc38SX0BdNyscDhs3ABQ2PQAzBx0VOjkRAHdcUURdNyMGAAVfRVUvPwQXEx0XMmxJWSQ4EBIUcCUXG01TTVt/bltDUi06DwckLRl9Yn9rD2VeZVdTRVI8PAsFHBUQLSoHFToIEEZGJSdeZVdTRVI6PRAOEAAEPScAQ39GQkdRWmJSEl5Ib1J/WUVDWl1FED0ACy1bVFcUPiMEBhASER0tfQkCGxUQPiwAc38SX0BdNyscDhs3ABQ2PQAzBx0VOjkRAHdcUURdNyMGAAVfRVUzMgsEABMCOmxJWSQ4EBIUcCUXG01TTVt/bltDUi06EworPgpzd3drD2VeZVdTRVI8PAsFHBUQLSoHFToIEEZGJSdeZVdTRVI6PRAOEAAEPScAQ39GQkdRWmJSEl5Ib1J/WUVDWl1FED0ACy1bVFcUPiMEBhASER0tfQkCGxUQPiwAClUSEF1GOSUbARYfIRc5OgsGJQAKLy4XDSYaXlNCOSUTGxgBSVJ4PwQNEgcEOC4WXnMSSzgUcGJSCBIHX1J3ekVeS1I+eBQ6NR58d2d1FwctMFAuSXh/c0VDFh0LOSICDC1TUl5RamIGHQIWSXh/c0VDEBwQMi4XGD1eVQgUJDAHCn1TRQ92aG9DVXhFf2RKWRBEVUBGOSYXTxkSExs4MhEMB1wNPjkBDj5AVXFbPiEHHQUWCxEmWUVDGgAMOCILGDN2VVRdPiciHRgDAAArKk0NFAQMOCoRFi0eEBVcMTAWGBYBADEwPQYWBwAAMSgcXnMSSzgUcGJSCBIHX1J3ekVeS1I6AAMkKxtlcWBxDwE9ITQmNyAaHSY6Ki1JVWtFWX9RX1xSOSUHHRYRCRdlcxERABdJVWtFWX9XXkdZNTATDRsWX1IrIRAGf1JFImJec38SOhIUf21SIAEWFwA2NwBDGxMTNiwEDTBAHlZRJisRCjoWCB0tKm9DVRsDf2NCHTpEWVFRHScfAAUKQlI2PUUNFAQMOCoRFi0bEEk+cGJSTxgBDBU2PQQPMRcDNiUAKS1dQFdGJDtaARYFDBU+JwoRWVJCOy4TEDxXfVdZPzALSFtTHnh/c0VDVVICOj9fWXcbEA8KcB0tKzIlLDEaDCgmOD03BhQ6VVUSEBIUcGIRABkVDBUqIQQBGRdffz8XDDoeOhIUcGJSTxIdEB86IQQBGRdffz8XDDo4EBIUcD9bVH1TRQ9Vc0VpVVJKcGsqDzpAQltQNWIBDAUWABx/IxcMBRcXKyIAClUSEF1GOSUbARYfIRc5OgsGJQAKLy4XDSYaQ1FGNSccQ1dUEhs7Jw1EWVIeVWtFWX9VVUYOcGpbT0pNRS0AACYxMDcrABwsPQt6b20YWmJST1cQChw5OgIWBxMHMy5fWStARVc+cGIPRkx5RVJVc0UMBxsCNiUEFRtXVltaNRIAAAcWFwYmexYABxcAMWdFXjdXWVVcJGVeTwx5RVJ/cwIGAUhFd2JFRGESb21nExA3KjksLTcWFC03Ki1JVWtFWX9RX1xSOSUHHRYRCRdlcxERABdvf2sYUGQ4EBI+cGIdHR4UDBw+PyEGExsLOhsXFi9XQkZNeDERHRIWC15/dAQVFBsJCCIBDTcVHBJPWmJST1cUAAZlc01KVU9bfxQ6KhxgdXd6DxU7KyM7Oi1zWUVDVVIGMCUDEDhHQlNWPCdITwMBEBdVc0UeXElvf2tvWX9dQltTOSwTAzMWAxsxNjURGgIALT8cUSxRQldRPm5SSBYFBBszGwAKEhoReGdFAlUSEBIUNycGVVdbTFJibUU8KjMzHgIpJhd3eXV8BB0tQ31TRVJ/MAoNExsCKjkEGzNXChJAIjcXZVdTGFtkWUVDf1JFMDkMHjZcUV5wNSQbARIjFx0vNhcXDFoWPDkAHDEeEBVXPy4dHTMWFQY3dElDDnhFf2tFHjpGChIceWJPUVcsOjEQHyoxKjYgDx8tJgAeOhIUcGIRABkVDBUqIQQBGRdffz8XDDo4EBJJeXl4T1d5RVIwIQwEHBwEMw8AHzZcVWJGPzIXHQMKTQE8IQAGG15FeDsMATpedFdEJCpVQ1cIb1J/c0UEEAZff2NMWWIMEG1rEw0+ICUsITcPBy08Kl5vf2tFWTxdXlRdNzcADhUfAEh/JxcWEHhFfzZMQlVPGRoda0g=';
    // Taskbar offset: Windows 40px, Mac 25px, Linux 28px
    final platform = config.platform.toLowerCase();
    final taskbarH = platform.contains('win') ? 40
        : platform.contains('mac') ? 25
        : 28;

    return SecurityObfuscator.decrypt(encrypted)
        .replaceAll('__USER_AGENT__', _escapeJs(config.userAgent))
        .replaceAll('__PLATFORM__', _escapeJs(config.platform))
        .replaceAll('__VENDOR__', _escapeJs(config.vendor))
        .replaceAll('__LANGUAGE__', _escapeJs(config.language))
        .replaceAll('__HARDWARE_CONCURRENCY__', config.hardwareConcurrency.toString())
        .replaceAll('__DEVICE_MEMORY__', config.deviceMemory.toString())
        .replaceAll('__MAX_TOUCH_POINTS__', config.maxTouchPoints.toString())
        .replaceAll('__DEVICE_PIXEL_RATIO__', config.devicePixelRatio.toString())
        .replaceAll('__SCREEN_WIDTH__', config.screenResolution.width.toString())
        .replaceAll('__SCREEN_HEIGHT__', config.screenResolution.height.toString())
        .replaceAll('__AVAIL_HEIGHT__', (config.screenResolution.height - taskbarH).toString())
        .replaceAll('__COLOR_DEPTH__', config.screenResolution.colorDepth.toString());
  }
  
  static String _escapeJs(String str) {
    return str
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('"', '\\"')
        .replaceAll('\n', '\\n')
        .replaceAll('\r', '\\r');
  }
}
