import 'package:flutter/foundation.dart';
import 'package:sec_tunnel/core/database/daos/profile_dao.dart';
import 'package:sec_tunnel/models/browser_profile.dart';
import 'package:uuid/uuid.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;

/// Business logic layer for profile management
class ProfileRepository {
  final ProfileDao _profileDao;
  final _uuid = const Uuid();
  
  ProfileRepository(this._profileDao) {
    debugPrint('[ProfileRepository] Created with ProfileDao');
  }
  
  Stream<List<BrowserProfile>> watchAllProfiles() {
    debugPrint('[ProfileRepository] watchAllProfiles called');
    return _profileDao.watchAllProfiles();
  }
  
  Future<List<BrowserProfile>> getAllProfiles() {
    debugPrint('[ProfileRepository] getAllProfiles called');
    return _profileDao.getAllProfiles();
  }
  
  Future<BrowserProfile?> getProfileById(String id) => _profileDao.getProfileById(id);
  
  Future<void> createProfile(BrowserProfile profile) async {
    // Ensure user data folder exists
    final folder = Directory(profile.userDataFolder);
    if (!await folder.exists()) {
      await folder.create(recursive: true);
    }
    
    await _profileDao.createProfile(profile);
  }
  
  Future<void> updateProfile(BrowserProfile profile) => _profileDao.updateProfile(profile);
  
  Future<void> deleteProfile(String id) async {
    final profile = await _profileDao.getProfileById(id);
    if (profile != null) {
      // Delete user data folder
      final folder = Directory(profile.userDataFolder);
      if (await folder.exists()) {
        await folder.delete(recursive: true);
      }
      
      await _profileDao.deleteProfile(id);
    }
  }
  
  /// Duplicates a profile with a new ID and isolated data folder.
  Future<void> duplicateProfile(BrowserProfile original) async {
    final newId = generateProfileId();
    final newFolder = await generateUserDataPath(newId);
    
    final clone = original.copyWith(
      id: newId,
      name: '${original.name} (Copy)',
      userDataFolder: newFolder,
      createdAt: DateTime.now(),
      lastUsedAt: DateTime.now(),
    );
    
    await createProfile(clone);
  }

  /// Completely clears the profile's local storage/cookies/session data
  /// while preserving the database record and configuration.
  Future<void> clearProfileSession(String id) async {
    final profile = await _profileDao.getProfileById(id);
    if (profile != null) {
      final folder = Directory(profile.userDataFolder);
      if (await folder.exists()) {
        await folder.delete(recursive: true);
        // Recreate empty folder immediately to prevent launch errors
        await folder.create(recursive: true);
      }
    }
  }
  
  Future<void> markAsUsed(String id) => _profileDao.updateLastUsed(id);
  
  /// Generate user data folder path for a profile
  Future<String> generateUserDataPath(String profileId) async {
    final appDocDir = await getApplicationDocumentsDirectory();
    return path.join(appDocDir.path, 'profiles', profileId);
  }
  
  /// Create a new profile ID
  String generateProfileId() => _uuid.v4();
}
